local oldUnit = Unit
Unit = Class(oldUnit) {
    OnDamage = function(self, instigator, amount, vector, damageType)
        -- Disable all friendly and team damage	
		local InstigatorArmy = instigator:GetArmy()
		local MyArmy = self:GetArmy()
		if InstigatorArmy == MyArmy or IsAlly(MyArmy, InstigatorArmy) == true then
            return 
        end
        
        oldUnit.OnDamage(self, instigator, amount, vector, damageType)
    end,
}