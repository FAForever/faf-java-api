version = 3
ScenarioInfo = {
    starts = true,
    preview = '',
    map = '/maps/SCMP 037/SCMP 037.scmap',
    save = '/maps/SCMP 037/SCMP 037_save.lua',
    script = '/maps/SCMP 037/SCMP 037_script.lua',
    norushradius = 35.000000,
    norushoffsetX_ARMY_1 = 0.000000,
    norushoffsetY_ARMY_1 = 0.000000,
    norushoffsetX_ARMY_2 = 0.000000,
    norushoffsetY_ARMY_2 = 0.000000,
    norushoffsetX_ARMY_3 = 0.000000,
    norushoffsetY_ARMY_3 = 0.000000,
    Configurations = {
        ['standard'] = {
            teams = {
                { name = 'Something', armies = {'ARMY_1','ARMY_2','ARMY_3',} },
            },
            customprops = {
            },
        },
    }}
