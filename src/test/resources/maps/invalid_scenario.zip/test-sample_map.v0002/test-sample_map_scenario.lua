version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Test-Sample Map",
}
