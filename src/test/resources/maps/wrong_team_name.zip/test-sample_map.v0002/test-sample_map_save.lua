--MANDATORY FILE--
In real world this is a text file.
Content will not be validated.