version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    description = "This map is for unit testing only",
    preview = '',
    map_version = 2,
    type = 'skirmish',
    starts = true,
    size = {256, 256},
    map = '/maps/test-sample_map.v0002/test-sample_map.scmap',
    save = '/maps/test-sample_map.v0002/test-sample_map_save.lua',
    script = '/maps/test-sample_map.v0002/test-sample_map_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
