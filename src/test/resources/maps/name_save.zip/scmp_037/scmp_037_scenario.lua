version = 3
ScenarioInfo = {
    name = 'Sludge_Test',
    description = "<LOC SCMP_037_Description>The thick, brackish water clings to everything, staining anything it touches. If it weren't for this planet's proximity to the Quarantine Zone, no one would ever bother coming here.",
    type = 'skirmish',
    starts = true,
    preview = '',
    size = {256, 256},
    map = '/maps/SCMP_037/save.scmap',
    map_version = 1,
    save = '/maps/SCMP_037/SCMP_037_save.lua',
    script = '/maps/SCMP_037/SCMP_037_script.lua',
    norushradius = 35.000000,
    norushoffsetX_ARMY_1 = 0.000000,
    norushoffsetY_ARMY_1 = 0.000000,
    norushoffsetX_ARMY_2 = 0.000000,
    norushoffsetY_ARMY_2 = 0.000000,
    norushoffsetX_ARMY_3 = 0.000000,
    norushoffsetY_ARMY_3 = 0.000000,
    Configurations = {
        ['standard'] = {
            teams = {
                { name = 'FFA', armies = {'ARMY_1','ARMY_2','ARMY_3',} },
            },
            customprops = {
            },
        },
    }}
