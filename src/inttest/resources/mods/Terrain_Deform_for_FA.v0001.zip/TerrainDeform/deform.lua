--
-- deform
-- Brent Allen 2007
-- www.scmods.net
--
-- Hooks: none
--
-- Public Functions: Deform
--
-- This file contains functions to perform terrain deformation. 
-- To trigger a deformation call Deform. Information on its parameters
-- is shown below. Currently supports round craters and custom deforms.
-- Later versions may add different deformation types.
--

-- Tracks the amount of deformation done throughout the map. Used to limit
-- deformation.
TerrainDeformMap = {}

-- Predefine functions
DeformThread = {}
DeformCrater = {}
DeformCustom = {}
PerformModifications = {}

-- Prevents deformations from modifying under water as well as from
-- pushing land below sea level.
NoWaterDeform = true

-- 
-- Deform
-- Performs a deformation on the terrain
--
-- x = x-Position on map for center of the deformation
-- z = z-Position on map for center of the deformation
--
-- DeformSettings is a table with the properties of the deform
--
-- DeformSettings = {
--
--   Crater = {     -- Include Crater to deform a standard crater
--     Radius = 5,  -- Radius of inner bowl
--     Width = 5,   -- Width of outer rim
--     Depth = 2,   -- Depth of bowl
--     Height = 1   -- Height of rim
--     }
--
--   -- Include Custom to define a custom shape for the deform
--   Custom = { {0 0 1 0 0},
--              {0 1 1 1 0},
--              {1 1 1 1 1},
--              {0 1 1 1 0},
--              {0 0 1 0 0} }
--   -- Custom is a double array of height offsets to be applied.
--   -- Custom should be used *sparingly* as it is not very effecient
--
-- }
--      
-- 
-- To call this function use
--    import('/mods/TerrainDeform/deform.lua').Deform(x, z, DeformSettings)
--
function Deform(x, z, DeformSettings)
    ForkThread(DeformThread, x, z, DeformSettings)
end


-- Called by Deform. Runs in a separate thread
function DeformThread(x, z, DeformSettings)
    if DeformSettings.Crater then
        local Crater = DeformSettings.Crater
        DeformCrater(x, z, Crater.Radius, Crater.Width, Crater.Depth, Crater.Height)
    end
    if DeformSettings.Custom then
        DeformCustom(x, z, DeformSettings.Custom)
    end
end

-- Accumulates total stretch to terrain at a point and returns the
-- previous value of stretch.
function TerrainStretch(x, z, amount)
    --Store the number of times we have modified the terrain
    if TerrainDeformMap[x] == nil then
        TerrainDeformMap[x] = {}
        TerrainDeformMap[x][z] = 0
    elseif TerrainDeformMap[x][z] == nil then
        TerrainDeformMap[x][z] = 0
    end
    local hitCount = TerrainDeformMap[x][z]
    TerrainDeformMap[x][z] = hitCount + amount
    return hitCount
end

-- Performs custom deformation.
-- Do not call this method directly. Use Deform instead.
function DeformCustom(x, z, CustomData)
    local modheights = {}
    local height = table.getn(CustomData)
    local width = table.getn(CustomData[1])

    x = math.floor(x) - width / 2
    z = math.floor(z) - height / 2

    for j = 1, height do
        for k = 1, width do
            local heightmod = -CustomData[j][k]
            local hitCount = math.abs(TerrainStretch(x+j, z+k, heightmod)) + 1
            
            -- Degrade the power of the modification.
            --
            -- This prevents ridiculous mounds accumulating
            -- when a point is hit many times
            heightmod = heightmod / hitCount

            local height = GetTerrainHeight(x + j, z + k)

            -- Store modification to be done later
            -- * Doing modifications immediatly throws off GetTerrainHeight
            --   function
            modheights[table.getn(modheights)+1] = {x+j, z+k, height - heightmod, height}
        end
    end
    PerformModifications(modheights)
end

-- This is called by the Deform function.
-- Do not call this method directly. Use Deform instead.
function DeformCrater(x, z, innerRadius, outerWidth, depth, craterHeight)
    local modheights = {}
    local maxradius = innerRadius
    local outerradius = outerWidth / 2

    local totalradius = maxradius + outerradius * 2

    -- Keep us on integer boundries
    x = math.floor(x)
    z = math.floor(z)

    --Calculate all height changes
    for j = -totalradius, totalradius-1 do
        for k = -totalradius, totalradius-1 do
            local radius = math.sqrt(j*j+k*k)
            if radius <= totalradius then
                local heightmod = 0

                if radius*radius < maxradius*maxradius then
                    -- Inner bowl
                    heightmod = (math.sqrt(maxradius*maxradius - radius*radius)) * depth / innerRadius
                else
                    -- Outer berm
                    if outerradius > 0 then
                        local r2 = outerradius + maxradius - radius
                        heightmod = -math.sqrt(outerradius*outerradius - r2*r2) * craterHeight / outerradius
                    end
                end

   
                local hitCount = math.abs(TerrainStretch(x+j, z+k, heightmod)) + 1

                -- Degrade the power of the modification.
                --
                -- This prevents ridiculous mounds accumulating
                -- when a point is hit many times
                heightmod = heightmod / hitCount
            
                local height = GetTerrainHeight(x + j, z + k)

                -- Store modification to be done later
                -- * Doing modifications immediatly throws off GetTerrainHeight
                --   function
                modheights[table.getn(modheights)+1] = {x+j, z+k, height - heightmod, height}

            end
        end
    end
    PerformModifications(modheights)
end

-- Once the shape of the deform has been determined this
-- function performs the modifications and adjusts props etc.
function PerformModifications(modheights)
    local sizeX, sizeZ = GetMapSize()

    -- Perform all modifications
    for i, v in modheights do
        -- Check to see if we are in the map
        if v[1] > 0 and v[2] > 0 and  v[1] < sizeX and v[2] < sizeZ then
            local terrainType = GetTerrainType(v[1], v[2])
            local actualChange = 0

            if terrainType.TypeCode >= 220 and NoWaterDeform then -- Water
                --Don't modify under water
            else
                FlattenMapRect(v[1], v[2], 0, 0, v[3])
                actualChange = v[4] - v[3]
                local surfaceHeight = GetSurfaceHeight(v[1], v[2])

                -- If we pushed the land below the surface (under water), 
                -- move it back up
                if NoWaterDeform and surfaceHeight > v[3] then
                   FlattenMapRect(v[1], v[2], 0, 0, surfaceHeight + 0.05)
                   actualChange = v[4] - (surfaceHeight + 0.05)
                end

                --Move all props affected my change

                --Grab props in area
                local rect = Rect(v[1], v[2], v[1]+1, v[2]+1)
                local ents = GetEntitiesInRect( rect )
                if ents then
					for i, e in ents do
                        if IsProp(e) then
                            local pos = e:GetPosition()
                            -- Check to see if it is *actually* in rect
                            -- * GetEntitiesInRect returns a larger area then 
                            --   requested.

                            if pos[1] >= v[1] and pos[1] < v[1]+1 then
                                if pos[3] >= v[2] and pos[3] < v[2]+1 then

                                    -- Move the prop
                                    pos[2] = pos[2] - actualChange
                                    e:SetPosition(Vector(pos[1], pos[2], pos[3]), true)
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end


