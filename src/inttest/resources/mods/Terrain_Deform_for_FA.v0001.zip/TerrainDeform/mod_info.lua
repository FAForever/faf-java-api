name = "Terrain Deform for FA"
version = 1
copyright = ""
description = "Terrain is cratered by heavy ordinance."
author = "Sorian(Current) Brent Allen(Original)"
url = ""

exclusive = false
ui_only = false

uid = "DF8825E2-DDB0-11DC-90F3-3F9B55D89593"