--
-- weapon
-- Brent Allen 2007
-- www.scmods.net
--
-- Hooks: Weapon.GetDamageTable (non-destructive)
--
-- Copies the DeformCraterOnImpact data to the weapon damage table from the
-- blueprint
--

local origWeapon = Weapon

Weapon = Class(Weapon) {

    GetDamageTable = function(self)
        local damageTable = origWeapon.GetDamageTable(self)
        local weaponBlueprint = self:GetBlueprint()
        damageTable.DeformTerrain = weaponBlueprint.DeformTerrain
        return damageTable
    end,
}

