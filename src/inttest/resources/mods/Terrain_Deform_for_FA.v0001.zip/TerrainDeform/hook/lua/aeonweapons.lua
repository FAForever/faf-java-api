--
-- aeonweapons
-- Brent Allen 2007
-- www.scmods.net
--
-- Hooks: AIFCommanderDeathWeapon.Fire (non-destructive)
--
-- Triggers terrain deformation when the death weapon is fired
--
-- Commander death weapons do not use the regular OnFire event. If deformation
-- occurs during the OnImpact event the deformation does not occur until after
-- the visual effects are completed. Deformation is performed here instead for
-- best performance.
--

local origAIFCommanderDeathWeapon = AIFCommanderDeathWeapon
AIFCommanderDeathWeapon = Class(origAIFCommanderDeathWeapon) {
    
    Fire = function(self)
        local bp = self:GetBlueprint()

        if bp.DeformTerrain then
            local x, y, z = unpack(self.unit:GetPosition())
            import('/mods/TerrainDeform/deform.lua').Deform(x, z, bp.DeformTerrain)
        end
        origAIFCommanderDeathWeapon.Fire(self)
    end,
}

