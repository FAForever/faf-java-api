--
-- projectile
-- Brent Allen 2007
-- www.scmods.net
--
-- Hooks: Projectile.PassDamageData (non-destructive)
--        Projectile.OnImpact (non-destructive)
--
-- PassDamageData:
-- Copies the DeformTerrain data from the weapon damage table to the 
-- projectile
--
-- OnImpact:
-- When the projectile hits something this function is called.
-- This performs deformation of the terrain if specified in the blueprint.
-- To specify add to the weapon blueprint 
-- DeformCraterOnImpact = {inner, outer, depth, height} 
-- where:
--   inner = inner radius of crater
--   outer = width of outer raised portion of crater
--   depth = maximum depth of crater
--   height = maximum height of crater wall
--

local origProjectile = Projectile
Projectile = Class(origProjectile) {

    PassDamageData = function(self, damageData)
        self.DeformTerrain = damageData.DeformTerrain
        origProjectile.PassDamageData(self, damageData)
    end,

    OnImpact = function(self, targetType, targetEntity)
        -- Check to see if we should perform deformation
        -- Don't deform if the weapon hit a shield or unit
        if self.DeformTerrain and targetType == "Terrain" then
            local x, y, z = unpack(self:GetPosition())
            import('/mods/TerrainDeform/deform.lua').Deform(x, z, self.DeformTerrain)
        end

        origProjectile.OnImpact(self, targetType, targetEntity)
    end,
}
