--
-- terranweapons
-- Brent Allen 2007
-- www.scmods.net
--
-- Hooks: TIFCommanderDeathWeapon.Fire (non-destructive)
--
-- Triggers terrain deformation when the death weapon is fired
--
-- Commander death weapons do not use the regular OnFire event. If deformation
-- occurs during the OnImpact event the deformation does not occur until after
-- the visual effects are completed. Deformation is performed here instead for
-- best performance.
--

local origTIFCommanderDeathWeapon = TIFCommanderDeathWeapon
TIFCommanderDeathWeapon = Class(origTIFCommanderDeathWeapon) {
    
    Fire = function(self)
        local bp = self:GetBlueprint()

        if bp.DeformTerrain then
            local x, y, z = unpack(self.unit:GetPosition())
            import('/mods/TerrainDeform/deform.lua').Deform(x, z, bp.DeformTerrain)
        end
        origTIFCommanderDeathWeapon.Fire(self)
    end,
}

