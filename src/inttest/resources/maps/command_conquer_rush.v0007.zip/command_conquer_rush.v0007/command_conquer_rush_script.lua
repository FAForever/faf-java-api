--[[
Don't edit or remove this comment block! It is used by the editor to store information since i'm too lazy to write a good LUA parser... -Haz
SETTINGS
RestrictedEnhancements=
RestrictedCategories=
END
--]]

--modification by Fuluper... FAQ, help and more in https://discord.gg/cVuFTAA P.S its Russian community

local ScenarioUtils = import('/lua/sim/ScenarioUtilities.lua')
local ScenarioFramework = import('/lua/ScenarioFramework.lua')

function OnPopulate()
  ScenarioUtils.InitializeArmies()
end

function OnStart(self)
	checkMassPoint()
end

local Tier1prop= "/env/Crystalline/Props/Rocks/CrysCrystal03_prop.bp"
local Tier2prop= "/env/Crystalline/Props/Rocks/CrysCrystal02_prop.bp"
local Tier3prop= "/env/Crystalline/Props/Rocks/CrysCrystal01_prop.bp"
local infoaboutextractors = {}

local allcreateprops = {}

function checkMassPoint()
	ForkThread( function()
	
		inform()
		while(true)do
			local MAPx, MAPz = GetMapSize()
			--filtered only extractors and masFabs
			local units=EntityCategoryFilterDown(categories.MASSEXTRACTION+(categories.MASSFABRICATION*categories.STRUCTURE), GetUnitsInRect({x0 = 0, x1 = MAPx, y0 = 0, y1 = MAPz})) 
			for id, unit in units do
				--LOG('Found')
				if infoaboutextractors[unit:GetEntityId()] == nil and not unit:IsDead() and unit:GetFractionComplete()>0.9 then
					local data = {}
					
					data.props=0
					data.pos=unit:GetPosition()
					if EntityCategoryContains(categories.MASSEXTRACTION,unit) then
						if EntityCategoryContains(categories.TECH3,unit) then
							data.createpersec=6
							data.maxdist=12
							data.maxprops=75
						elseif EntityCategoryContains(categories.TECH2,unit) then
							data.createpersec=4
							data.maxdist=11
							data.maxprops=60
						elseif EntityCategoryContains(categories.TECH1,unit) then
							data.createpersec=2
							data.maxdist=8
							data.maxprops=40
						else
							LOG('ERROR MAP categories for massextractor')
							continue
						end
					end
					if EntityCategoryContains(categories.MASSFABRICATION*categories.STRUCTURE,unit) then
						if EntityCategoryContains(categories.TECH3,unit) then
							data.createpersec=6
							data.maxdist=10
							data.maxprops=100
						elseif EntityCategoryContains(categories.TECH2,unit) then
							data.createpersec=1
							data.maxdist=5
							data.maxprops=15
						else
							LOG('ERROR MAP categories for massfabrication')
							continue
						end
					end
					data.timeupgrade=10
					data.unit=unit
					infoaboutextractors[unit:GetEntityId()] = data
				end
			end
			for id,data in infoaboutextractors do
				if data.unit == nil or data.unit:IsDead() then
					infoaboutextractors[id]=nil
				end
			end
			mainCreate()
			WaitSeconds( 1 )
			getmaxprops()
			WaitSeconds( 2 )
		end
	end)
end


local prop1= nil
local prop2= nil
local prop3= nil

function mainCreate()

	--create
	if not table.empty(infoaboutextractors) then
		for id,data in infoaboutextractors do
			if data.props<data.maxprops then
				createp(data)
			end
		end

	end
	
	--upgrade
	if not table.empty(allcreateprops) then
		for id,data in allcreateprops do
			if not data.prop:BeenDestroyed() then
				if data.tier<3 and (GetGameTimeSeconds()-data.timecreate)>data.timeforupgrade then
					data.prop:Destroy()
					if data.tier==1 then
					data.prop=CreateProp(data.pos,Tier2prop)
					data.tier=2
						if prop2 ==nil then
							prop2=data.prop
						end
					elseif data.tier==2 then
					data.prop=CreateProp(data.pos,Tier3prop)
					data.tier=3
						if prop3 ==nil then
							prop3=data.prop
						end
					end
					data.timecreate=GetGameTimeSeconds()
				end
			else
				allcreateprops[id]=nil
			end
		end
	end

end






function createp(data)
	--Data mex or fab
	for i = 1, data.createpersec do
		local pos=data.pos
		local posx=pos[1]
		local posz=pos[3]
		if(math.random(0,1)==1) then
			posx=pos[1]+math.random(0,data.maxdist)
		else
			posx=pos[1]-math.random(0,data.maxdist)
		end
		if(math.random(0,1)==1) then
			posz=pos[3]+math.random(0,data.maxdist)
		else
			posz=pos[3]-math.random(0,data.maxdist)
		end
		
		
		--Data(kr/crystal) prop
		local datakr = {}
		datakr.pos=VECTOR3(posx,pos[2],posz)
		if prop1 ==nil then
			prop1 = CreateProp(datakr.pos, Tier1prop)
			datakr.prop=prop1
		else
			datakr.prop=CreateProp(datakr.pos, Tier1prop)
		end
		datakr.tier=1
		datakr.timeforupgrade=data.timeupgrade
		datakr.timecreate=GetGameTimeSeconds()
		table.insert(allcreateprops,datakr)
	end
end

function getmaxprops()
	if not table.empty(infoaboutextractors) then
		for id,data in infoaboutextractors do
			local count=0
			local props = GetReclaimablesInRect({x0 = data.pos[1]-(data.maxdist+1), x1 = data.pos[1]+(data.maxdist+1), y0 = data.pos[3]-(data.maxdist+1), y1 = data.pos[3]+(data.maxdist+1)})
			if not table.empty(props) then
				for j,r in props do
					--LOG(r:GetBlueprint().BlueprintId)
						if r:GetBlueprint()==prop1:GetBlueprint() then
							count=count+1
						elseif prop2~=nil and r:GetBlueprint()==prop2:GetBlueprint() then 
							count=count+1
						elseif prop3~=nil and r:GetBlueprint()==prop3:GetBlueprint() then
							count=count+1
						end
					
				end
			end
			data.props=count
			--LOG('MAPMAP test radom s mexom '..count..' '.. infoaboutextractors[id].props )

		end
	end
end

function inform()
    WaitSeconds(2)
    BroadcastMSG('Mexs and massfab create crystals',  -- message
                 20,                                                             -- fontsize
                 'd0d0d0',                                                       -- color
                 15,                                                             -- duration
                 'leftcenter')                                                       -- position
end

function BroadcastMSG(message, fontsize, RGBColor, duration, location)
----------------------------------------
-- broadcast a text message to players
-- possible locations = lefttop, leftcenter, leftbottom,  righttop, rightcenter, rightbottom, rightbottom, centertop, center, centerbottom
----------------------------------------
    PrintText(message, fontsize, 'ff' .. RGBColor, duration , location) ;
end
